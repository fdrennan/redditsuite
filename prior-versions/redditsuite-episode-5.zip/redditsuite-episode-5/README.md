
<!-- README.md is generated from README.Rmd. Please edit that file -->

# redditsuite

Git location per episode

## Episode 5

[Github Link](https://github.com/fdrennan/redditsuite/tree/episode-5)

Commands used in Episode 5

    wget https://raw.githubusercontent.com/fdrennan/redditsuite/dev-freeze-1/R/connection_postgres.R
